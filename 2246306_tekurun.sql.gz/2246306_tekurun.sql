-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: fdb12.awardspace.net
-- Üretim Zamanı: 20 Ara 2016, 15:37:45
-- Sunucu sürümü: 5.7.16-log
-- PHP Sürümü: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `2246306_tekurun`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `banka`
--

CREATE TABLE `banka` (
  `id` int(2) NOT NULL COMMENT 'ID',
  `hesap` text COMMENT 'Hesap Bilgileri'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `banka`
--

INSERT INTO `banka` (`id`, `hesap`) VALUES
(1, '<p style="text-align: center;">Yapı Kredi</p><p style="text-align: center;">John Doe</p><p style="text-align: center;">IBAN: TR0000000000000000000000</p>');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iyzico`
--

CREATE TABLE `iyzico` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `apikey` varchar(255) DEFAULT NULL COMMENT 'iyzico apikey',
  `secret` varchar(255) DEFAULT NULL COMMENT 'iyzico secret'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `iyzico`
--

INSERT INTO `iyzico` (`id`, `apikey`, `secret`) VALUES
(1, 'sandbox-eJqdO5uIHkxRDEQXxfAgymKWHywdBCyi', 'sandbox-qOyOdQj47IaRs4fVGaJzGtdEJx0rzVBM');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) CHARACTER SET latin1 NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1476829377),
('m130524_201442_init', 1476829380),
('m161018_223601_create_settings_table', 1476830486);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `resim`
--

CREATE TABLE `resim` (
  `id` int(1) NOT NULL COMMENT 'id',
  `anasayfa` varchar(255) DEFAULT NULL COMMENT 'Anasayfa Resmi',
  `sol` varchar(255) DEFAULT NULL COMMENT 'Sol Resim',
  `orta` varchar(255) DEFAULT NULL COMMENT 'Orta Resim',
  `sag` varchar(255) DEFAULT NULL COMMENT 'Sağ Resim',
  `sagbanner` varchar(255) DEFAULT NULL COMMENT 'Anasayfa Sağ Banner'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `resim`
--

INSERT INTO `resim` (`id`, `anasayfa`, `sol`, `orta`, `sag`, `sagbanner`) VALUES
(1, 'anasayfa.png', 'sol.png', 'orta.png', 'sag.png', 'sagbanner.png');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT 'Site Adı',
  `title` varchar(255) DEFAULT NULL COMMENT 'Site Başlığı',
  `description` text COMMENT 'Site Açıklaması',
  `keyword` varchar(255) DEFAULT NULL COMMENT 'Anahtar Kelimeler',
  `telefon` varchar(255) DEFAULT NULL COMMENT 'Telefon Numarası',
  `kapida` tinyint(1) NOT NULL COMMENT 'Kapıda Ödeme',
  `banka` tinyint(1) NOT NULL COMMENT 'Banka Havalesi',
  `iyzico` tinyint(1) NOT NULL COMMENT 'iyzico'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `setting`
--

INSERT INTO `setting` (`id`, `name`, `title`, `description`, `keyword`, `telefon`, `kapida`, `banka`, `iyzico`) VALUES
(1, 'Kırışıklık Giderici', 'Kırışıklık Giderici', 'Tek ürün satış scripti, ürünlerimizi sitemizden alabilirsiniz.', 'tek ürün, satış, zayıflama, test', '02324116262', 1, 0, 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparis`
--

CREATE TABLE `siparis` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `adsoyad` varchar(255) DEFAULT NULL COMMENT 'Ad Soyad',
  `odemetipi` varchar(255) DEFAULT NULL COMMENT 'Ödeme Tipi',
  `urun` varchar(255) NOT NULL,
  `fiyat` float(5,2) NOT NULL,
  `email` varchar(255) DEFAULT NULL COMMENT 'E-posta',
  `telefon` varchar(255) DEFAULT NULL COMMENT 'Telefon',
  `sehir` varchar(255) DEFAULT NULL COMMENT 'Şehir',
  `ilce` varchar(255) DEFAULT NULL COMMENT 'İlçe',
  `adres` text COMMENT 'Adres',
  `ozel` text COMMENT 'Özel Not',
  `durum` varchar(64) NOT NULL DEFAULT 'Yeni' COMMENT 'Sipariş Durumu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `siparis`
--

INSERT INTO `siparis` (`id`, `adsoyad`, `odemetipi`, `urun`, `fiyat`, `email`, `telefon`, `sehir`, `ilce`, `adres`, `ozel`, `durum`) VALUES
(30, 'Meryem Güney', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsadfsafsa', '', 'Havale Bekleniyor'),
(31, 'Meryem Güney', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsadfsafsa', '', 'Yeni'),
(32, 'Jane Doe', 'Kapıda Ödeme', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Yeni'),
(33, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(34, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(35, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(36, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(37, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(38, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(39, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(40, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(41, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(42, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(43, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(44, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(45, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(46, 'Jane Doe', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafdsa', '', 'Havale Bekleniyor'),
(47, 'Meryem Güney', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfafddasf', '', 'Ödeme Bekleniyor'),
(48, 'Meryem Güney', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfafddasf', '', 'Ödeme Bekleniyor'),
(49, 'Meryem Güney', 'Kapıda Ödeme', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfafddasf', '', 'Yeni'),
(50, 'Meryem Güney', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfafddasf', '', 'Havale Bekleniyor'),
(51, 'Meryem Güney', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfafddasf', '', 'Havale Bekleniyor'),
(52, 'Meryem Güney', 'Havale/EFT', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfafddasf', '', 'Havale Bekleniyor'),
(53, '', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, '', '', 'İstanbul', NULL, '', '', 'Ödeme Bekleniyor'),
(54, 'Jane Doe', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafsafs', '', 'Ödeme Bekleniyor'),
(55, 'Jane Doe', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfsafsafs', '', 'Yeni'),
(56, 'Jane Doe', 'Kapıda Ödeme', '3 Adet Kırışıklık Giderici', 69.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfasfas', '', 'Yeni'),
(57, 'Jane Doe', 'Kapıda Ödeme', '3 Adet Kırışıklık Giderici', 69.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'sdfasfas', '', 'Yeni'),
(58, '', 'Kapıda Ödeme', '2 Adet Kırışıklık Giderici', 59.90, '', '', 'İstanbul', NULL, '', '', 'Yeni'),
(59, '', 'Havale/EFT', '2 Adet Kırışıklık Giderici', 59.90, '', '', 'İstanbul', NULL, '', '', 'Havale Bekleniyor'),
(60, 'Jane Doe', 'iyzico', '3 Adet Kırışıklık Giderici', 69.90, 'deneme@eposta.com', '5511646464', 'İstanbul', NULL, '765 sokak', '', 'Yeni'),
(61, 'Meryem Güney', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, '', '', 'Ödeme Bekleniyor'),
(62, 'Meryem Güney', 'iyzico', '1 Adet Kırışıklık Giderici', 39.90, 'deneme@test.com', '05511747576', 'İstanbul', NULL, 'deneme test', '', 'Ödeme Bekleniyor'),
(63, 'cem', 'iyzico', '2 Adet Kırışıklık Giderici', 59.90, 'dbasdk@gmail.com', 'o536489455', 'İstanbul', NULL, 'asfd açv svkn adkçv sd vksdnv şsd', '', 'Ödeme Bekleniyor'),
(64, 'fdassf', 'iyzico', ' Adet Kırışıklık Giderici', 39.90, 'fasdf@gfd.fsda', '4324234', 'İstanbul', NULL, 'fasdf', 'fasdf', 'Ödeme Bekleniyor'),
(65, 'fdassf', 'Kapıda Ödeme', ' Adet Kırışıklık Giderici', 39.90, 'ds@fasd.fg', '4324234', 'İstanbul', NULL, 'fdg', '', 'Yeni'),
(66, 'Bogac Test', 'iyzico', ' Adet Kırışıklık Giderici', 39.90, 'asfsafsafsafs', '55367670', 'İstanbul', NULL, 'falan filan', '', 'Ödeme Bekleniyor'),
(67, 'Bogac Test', 'iyzico', ' Adet Kırışıklık Giderici', 39.90, 'destek@dataworkz.xyz', '55367670', 'İstanbul', NULL, 'falan filan', '', 'Ödeme Bekleniyor'),
(68, 'Bogac Test', 'iyzico', '2 Adet Kırışıklık Giderici', 59.90, 'destek@dataworkz.xyz', '55367670', 'İstanbul', NULL, 'asfsafsafsafsf', '', 'Ödeme Bekleniyor'),
(69, 'Bogac Test', 'iyzico', ' Adet Kırışıklık Giderici', 39.90, 'destek@dataworkz.xyz', '55367670', 'Ankara', NULL, 'falan filan', '', 'Ödeme Bekleniyor'),
(70, 'sdm dsam', 'Kapıda Ödeme', '2 Adet Kırışıklık Giderici', 59.90, 'as@sad.com', 'sdm dsam', 'İstanbul', NULL, 'sdmlsa', '', 'Yeni');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urun`
--

CREATE TABLE `urun` (
  `id` int(1) NOT NULL COMMENT 'ID',
  `adi` varchar(255) DEFAULT NULL COMMENT 'Ürün Adı',
  `aciklama` text COMMENT 'Ürün Açıklaması',
  `video` varchar(255) DEFAULT NULL COMMENT 'Video URL',
  `nasil` text COMMENT 'Nasıl Kullanılır?',
  `tekfiyat` float(5,2) DEFAULT NULL COMMENT 'Tek Ürün Fiyatı',
  `ikifiyat` float(5,2) DEFAULT NULL COMMENT 'İki Ürün Fiyatı',
  `ucfiyat` float(5,2) DEFAULT NULL COMMENT 'Üç Ürün Fiyatı',
  `kargo` float(5,2) DEFAULT NULL COMMENT 'Kargo Ücreti'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `urun`
--

INSERT INTO `urun` (`id`, `adi`, `aciklama`, `video`, `nasil`, `tekfiyat`, `ikifiyat`, `ucfiyat`, `kargo`) VALUES
(1, 'Kırışıklık Giderici', '<p>Cildindeki siyah noktalardan rahatsızlık duyanlar için ideal ürünler arasında yer alıyor.<strong>Tek ürün satış sitesi</strong> Limon asidi ile zenginleştirilmiş olan bu bantların sadece burun için olanlarını bulabileceğiniz gibi wordpress tek sayfa ürün satış teması T bölgesi dediğimiz burun, alın ve çene için olanlarını da bulabilirsiniz. Tek ürün satış sitesi bunlar sayesinde cildinizdeki gözeneklerde biriken kir ve yağdan 15 dakika içerisinde kurtulabilmeniz mümkün olacaktır.</p><p>Siyah Nokta Kremi su ile aktif hale gelmektedir. Yıkadığınız yüzünüzü kurulamadan kullanacağınız bu bantlar sayesinde cildinizin derinlemesine temizlendiğini görebilirsiniz. Kullanımı da oldukça kolay olması sebebi ile bu konuyla ilgili sıkıntı yaşayan kişilerin rahatlıkla kullanabileceği ürünler arasında yer alır.</p>', 'http://www.youtube.com/embed/qva72Tn07io', '<p>Ürün ve yanak bölgesinde meydana gelen siyah noktaları gidermek üzere geliştirilen bu kremler, cilt ılık suyla temizlendikten sonra uygulanmalıdır. Cilt ılık suyla yumuşatıldıktan sonra uygulanan krem 10 dakika bekletildikten sonra temizlenmelidir. Tek Ürün Scpirt Yatmadan önce uygulanan krem sürme işlemi gece boyunca cildin yenilenmesini sağlayacaktır.</p><p>Siyah nokta kremi sürmeden önce buhar maskesi uygulayarak cildinizdeki gözeneklerin yumuşamasını sağlayabilirsiniz. Papatya bitkisini kaynatıp onun suyu ile buhar maskesi uygulamanız daha etkili olacaktır. Buhar maskesi sayesinde krem sürdükten sonra siyah noktalar daha kolay temizlenecektir.</p><p>Siyah nokta temizleme özellikli kremlerin bazıları peeling etkilidir. İçinde tanecikler bulunan bu kremler, cildi sivilceye yatkın kişiler tarafından kullanılmamalıdır. Peeling etkili kremler, sivilcelerin çoğalmasına neden olabilmektedir.</p>', 39.90, 59.90, 69.90, 5.00);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ad7MOs6xAdCCNr7lySdxAEbJIPDwCPMo', '$2y$13$J41TrnbJ7xkqb/XlOsyLwu7YngObk.EGjnqEgh7Nh9DJmv0Lafy.i', NULL, 'admin@example.com', 10, 1476829726, 1476829726);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorum`
--

CREATE TABLE `yorum` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `ad` varchar(255) DEFAULT NULL COMMENT 'Ad Soyad',
  `sehir` varchar(255) DEFAULT NULL COMMENT 'Şehir',
  `yorum` text COMMENT 'Yorum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `yorum`
--

INSERT INTO `yorum` (`id`, `ad`, `sehir`, `yorum`) VALUES
(1, 'Şehnaz K.', 'İstanbul', 'Çok güzel bir ürün. Kullanmaya başladığım ilk günden itibaren faydasını gördüm.'),
(2, 'Melis C.', 'Ankara', 'Ürün 1 gün içerisinde bana ulaştı. Hemen etkisini gösterdi. Çok memnunum, herkese tavsiye ederim.');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `banka`
--
ALTER TABLE `banka`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `iyzico`
--
ALTER TABLE `iyzico`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Tablo için indeksler `resim`
--
ALTER TABLE `resim`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `siparis`
--
ALTER TABLE `siparis`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `urun`
--
ALTER TABLE `urun`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- Tablo için indeksler `yorum`
--
ALTER TABLE `yorum`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `iyzico`
--
ALTER TABLE `iyzico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `resim`
--
ALTER TABLE `resim`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT COMMENT 'id', AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `siparis`
--
ALTER TABLE `siparis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=71;
--
-- Tablo için AUTO_INCREMENT değeri `urun`
--
ALTER TABLE `urun`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `yorum`
--
ALTER TABLE `yorum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
